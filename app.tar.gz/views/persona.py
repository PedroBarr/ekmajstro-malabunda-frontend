import flet as ft
import asyncio
import re

from consts import etiquetas
from utils import rutas
from api_client import ClienteAPI

from models.persona import Persona

from components.carta_persona import CartaPersona
from components.caja_mensaje import caja_cargando, caja_error

ruta = rutas[etiquetas["DETAIL"]](":id")
ruta_creacion = rutas[etiquetas["DETAIL"]](None)

class PersonaVista:
    def __init__(self, pagina: ft.Page, es_creacion: bool = False):
        self.pagina = pagina
        self.persona: Persona = Persona.sintetizar()
        self._actualizar_persona()
        self.construir(es_creacion=es_creacion)

    def _actualizar_persona(self):
        self._persona = Persona.sintetizar(persona=self.persona)

    def _obtener_id(self):
        ruta_actual = self.pagina.route
        patron = rutas[etiquetas["DETAIL"]](r"([A-Za-z0-9]+)")
        coincidencia = re.match(patron, ruta_actual)
        if coincidencia:
            self.persona.id = coincidencia.group(1)
        else:
            asyncio.create_task(self._validar_ruta_inutil())

    async def _validar_ruta_inutil(self):
        terna_vistas = self.pagina.views[-3:] if len(self.pagina.views) >= 3 else self.pagina.views
        if (
            terna_vistas[0].route == terna_vistas[-1].route == "/persona" and
            terna_vistas[1].route == ruta
        ):
            await self.pagina.on_view_pop(True)
            await self.pagina.on_view_pop(True)
            await self.pagina.on_view_pop(None)

    async def cargar_datos(self):
        self._obtener_id()
        if self.persona.id:
            try:
                self.persona = await ClienteAPI().obtener_persona(
                    self.persona.id
                )
                self._actualizar_persona()
            except Exception as e: self.persona = None

        self._actualizar_carta()
        self.pagina.update()
        
    async def _sincronizar_cambios(self, cambios: dict):
        try:
            if self.persona.id:
                await ClienteAPI().parchar_persona(
                    self.persona.id,
                    cambios
                )

                self._actualizar_persona()
            else:
                self.vista.controls = [
                    caja_cargando(
                        etiquetas["LOADING_SYNC"],
                        size=20,
                    )
                ]
                self.pagina.update()
                nueva_persona = await ClienteAPI().crear_persona(self.persona)
                if nueva_persona and nueva_persona.id:
                    ruta_nueva = rutas[etiquetas["DETAIL"]](nueva_persona.id)
                    await self.pagina.push_route(ruta_nueva)

        except Exception as e: self.persona = None
        

    async def _modificar_persona(self, persona: Persona):
        cambios = self._persona.cambios(persona)
        if cambios:
            if persona.es_cargable():
                asyncio.create_task(self._sincronizar_cambios(cambios))
            else: print(etiquetas["UNCOMPLETED_FIELDS"])
                    
        self.persona = persona
        self._actualizar_carta()
        self.pagina.update()
    
    def _controles(self):
        return ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                CartaPersona(
                    persona=self.persona,
                    al_cambio=lambda p: \
                        asyncio.create_task(
                            self._modificar_persona(p)
                        ),
                    editable=True,
                    expand=1,
                    elevation=5,
                ),
                ft.Container(expand=1),
            ]
        )
    
    def _carta_fallida(self):
        return caja_error(
            etiquetas["ERROR_LOADING_DETAIL"],
            size=20,
        )
    
    def _actualizar_carta(self):
        self.vista.controls = [
            self._controles() if self.persona else self._carta_fallida()
        ]

    def construir(self, es_creacion=False):
        self.vista = ft.View(
            route=ruta if not es_creacion else ruta_creacion,
            controls=[self._controles()],
        )